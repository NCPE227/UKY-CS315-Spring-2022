import time 

#Taken from Class Lecture
#File Read-In
def ReadIn(string):
    filename = string
    file = open(filename, "r")
    
    lines = file.readlines()

    powerList = []
    #Clean all of my lines
    lines.pop(0)
    for i in range(len(lines)):
        lines[i]=lines[i].rstrip("\n")
        lines[i] = lines[i].split(",")
        lines[i][1] = int(lines[i][1])
        powerList.append(lines[i][1])
    return powerList
    #print(powerList, "\n")



#Quick Sort
def partition(array, low, high):
    i = (low - 1)
    pivot = array[high] #pick the pivot point for quicksort

    for j in range(low, high):
        if array[j] <= pivot:
            i = (i + 1)
            array[i] = array[j] 
            array[j] = array[i]
            array[i+1] = array[high] 
            array[high] = array[i+1]
        return (i + 1)
#end of partition()
quick = 0
def QuickSort(array, low, high):
        global quick
        if (len(array) == 1):
                return array
        if (low < high):
            index = partition(array, low, high) #partition index
            quick = quick + 1
            QuickSort(array, low, index-1)
            QuickSort(array, index+1, high)
#end of QuickSort()
#end of Quick Sort

#Merge Sort
merge = 0
def MergeSort(array):
        global merge
        if len(array) > 1:
                mid = len(array)//2 #find the middle value
                
                #divide the array elements
                left = array[:mid]
                right = array[mid:]

                #sort each half
                MergeSort(left)
                MergeSort(right)

                i = 0 
                j = 0
                k = 0
                while i < len(left) and j < len(right):
                    if left[i] < right[j]:
                        array[k] = left[i]
                        i += 1
                    else:
                        array[k] = right[j]
                        j += 1
                    k += 1
                
                while i < len(left):
                    array[k] = left[i]
                    i += 1
                    k += 1    
                merge += 1
    #end of MergeSort()        
#end of Merge Sort


#Insertion Sort
insert = 0
def InsertionSort(array):
    global insert
    if len(array) > 1:
        for i in range(1, len(array)):
            key = array[i]
            j = i-1

            while j >= 0 and key < array[j]:
                array[j+1] = array[j]
                j -= 1
                array[j+1] = key
                insert = insert + 1
#end of InsertionSort()
#end of Insertion Sort

#Sort A Set With Each Algorithm
def SortWithAll(array):
    global insert, quick, merge
    InsertionSort(array)
    print("\nInsert Comparison: ", insert)
    print(array)

    MergeSort(array)
    print("\nMerge Comparisons: ", merge)
    print("\n", array)
  
    QuickSort(array, 0, len(array)-1)
    print("\nQuick Comparisons: ", quick)
    print(array)

    insert = 0
    quick = 0
    merge = 0

#Read File Data Into Array
#Gen 1
G1_Random = ReadIn("pokemonRandomSmall.csv")
G1_Sorted = ReadIn("pokemonSortedSmall.csv")
G1_Reverse = ReadIn("pokemonReverseSortedSmall.csv")

#Gen 1 to Gen 3
G1to3_Random = ReadIn("pokemonRandomMedium.csv")
G1to3_Sorted = ReadIn("pokemonSortedMedium.csv")
G1to3_Reverse = ReadIn("pokemonReverseSortedMedium.csv")

#Gen 1 to Gen 6
G1to6_Random = ReadIn("pokemonRandomLarge.csv")
G1to6_Sorted = ReadIn("pokemonSortedLarge.csv")
G1to6_Reverse = ReadIn("pokemonReverseSortedLarge.csv")

#Random Set Sorted
print("Random Sets")
print("Gen 1")
SortWithAll(G1_Random)
print("\nGen 1 to 3")
SortWithAll(G1to3_Random)
print("\nGen 1 to 6")
SortWithAll(G1to6_Random)


#Sorted Set Sorted
print("\nSorted Sets")
print("Gen 1")
SortWithAll(G1_Sorted)
print("\nGen 1 to 3")
SortWithAll(G1to3_Sorted)
print("\nGen 1 to 6")
SortWithAll(G1to6_Sorted)

#Reverse Sorted Set Sorted
print("\nReverse Sorted")
print("Gen 1")
SortWithAll(G1_Reverse)
print("\nGen 1 to 3")
SortWithAll(G1to3_Reverse)
print("\nGen 1 to 6")
SortWithAll(G1to6_Reverse)

print("\n\n")
